export type FoodItem = { id: number; name: string; description: string; category: string; price: number; emoji: string; available: boolean; popular?: boolean };
export type CartItem = FoodItem & { quantity: number };
export type Order = { id: string; items: CartItem[]; total: number; slot: string; status: "Placed" | "Preparing" | "Ready for pickup"; createdAt: string };
