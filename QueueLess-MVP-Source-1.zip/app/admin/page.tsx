 "use client";
import Header from "@/components/Header";
import { useApp } from "@/context/AppContext";
export default function AdminPage() {
 const { orders, menu, toggleAvailability, updateOrderStatus } = useApp();
 return <><Header/><main className="container subpage"><span className="eyebrow">CANTEEN WORKSPACE</span><h1>Staff <em>dashboard</em></h1><p className="muted">Demo controls for order preparation and menu availability.</p>
 <div className="admin-grid"><section className="panel"><h2>Incoming orders <span>{orders.length}</span></h2>{orders.length===0?<p className="muted">No orders have been placed yet.</p>:orders.map(o=><div className="admin-row" key={o.id}><div><b>{o.id}</b><p>{o.items.map(i=>`${i.name} ×${i.quantity}`).join(", ")}</p><small>{o.slot} · ₹{o.total}</small></div><button className="btn btn-light" onClick={()=>updateOrderStatus(o.id)}>{o.status==="Ready for pickup"?"Ready ✓":"Update status"}</button></div>)}</section>
 <section className="panel"><h2>Menu availability</h2>{menu.map(item=><div className="admin-row" key={item.id}><div><b>{item.name}</b><p>₹{item.price}</p></div><button className={`availability ${item.available?"available":"unavailable"}`} onClick={()=>toggleAvailability(item.id)}>{item.available?"Available":"Sold out"}</button></div>)}</section></div>
 <p className="notice">This is a frontend demonstration. Orders and menu changes are held in browser memory and are not shared across devices.</p></main></>;
}
