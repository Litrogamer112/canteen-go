import Header from "@/components/Header";
import Menu from "@/components/Menu";
import Link from "next/link";
export default function Home() {
  return <><Header /><main className="container">
    <section className="hero">
      <div><span className="eyebrow">THE CAMPUS CANTEEN, REIMAGINED</span>
        <h1>Your break.<br/><em>Without the queue.</em></h1>
        <p>Order your favourites before the bell rings. Choose a pickup slot and spend your break enjoying it—not waiting for it.</p>
        <div className="hero-actions"><a className="btn btn-primary" href="#menu">Explore menu <span>↗</span></a><Link className="btn btn-light" href="/orders">Track my orders</Link></div>
        <div className="trust"><span className="dot"/> Demo canteen · Sample menu · No real payments</div>
      </div>
      <div className="hero-card"><div className="hero-card-top"><span>Today's canteen</span><span className="status-pill">● Open</span></div>
        <div className="hero-emoji">🥪</div><h3>Good food. More free time.</h3><p>Pick a meal, select a time, and collect when it's ready.</p>
        <div className="mini-stats"><div><b>3</b><small>Pickup slots</small></div><div><b>12+</b><small>Menu choices</small></div><div><b>1 tap</b><small>To reorder</small></div></div>
      </div>
    </section>
    <section className="section-head" id="menu"><div><span className="eyebrow">MADE FOR YOUR BREAK</span><h2>What's on the menu?</h2><p>Fresh picks for your campus cravings.</p></div><Link href="/orders" className="text-link">Your orders →</Link></section>
    <Menu />
    <section className="how"><div><span className="eyebrow">THREE SIMPLE STEPS</span><h2>More break.<br/>Less waiting.</h2></div>
      <div className="steps"><article><b>01</b><h3>Choose your food</h3><p>Browse the menu and add your favourites to the cart.</p></article><article><b>02</b><h3>Pick a time</h3><p>Select a pickup slot that works with your class break.</p></article><article><b>03</b><h3>Collect & enjoy</h3><p>Check your order status and collect when it is ready.</p></article></div>
    </section>
  </main><footer>QueueLess <span>Student project MVP · Built for campus life</span></footer></>;
}
