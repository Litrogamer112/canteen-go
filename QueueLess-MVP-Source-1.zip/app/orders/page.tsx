 "use client";
import Header from "@/components/Header";
import { useApp } from "@/context/AppContext";
export default function OrdersPage() {
 const { orders, updateOrderStatus } = useApp();
 return <><Header/><main className="container subpage"><span className="eyebrow">YOUR ACTIVITY</span><h1>Order <em>tracker</em></h1><p className="muted">Follow your demo orders from placement to pickup.</p>
 {orders.length===0 ? <div className="empty"><div>🧾</div><h2>No orders yet</h2><p>Your placed orders will show up here.</p><a className="btn btn-primary" href="/">Browse menu</a></div> :
 <div className="order-list">{orders.map(o=><article className="order-card" key={o.id}><div className="order-top"><div><small>ORDER {o.id}</small><h3>{o.items.map(i=>i.name).join(", ")}</h3></div><span className="status-pill">{o.status}</span></div><p>Pickup: <b>{o.slot}</b> · Total: <b>₹{o.total}</b></p><div className="progress"><span className={o.status!=="Placed"?"done":""}/><span className={o.status==="Ready for pickup"?"done":""}/><span className={o.status==="Ready for pickup"?"done":""}/></div><div className="order-actions"><small>Demo staff controls</small><button className="btn btn-light" onClick={()=>updateOrderStatus(o.id)}>Advance status ↗</button></div></article>)}</div>}
 </main></>;
}
