import type { Metadata } from "next";
import "./globals.css";
import { AppProvider } from "@/context/AppContext";
export const metadata: Metadata = {
  title: "QueueLess | Smart Campus Canteen",
  description: "Order ahead. Skip the wait. A campus canteen pre-ordering MVP."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><AppProvider>{children}</AppProvider></body></html>;
}
