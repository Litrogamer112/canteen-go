# QueueLess — Smart Campus Canteen MVP

A frontend MVP built with Next.js App Router, React Context, TypeScript and CSS.

## Features
- Menu with category filters and search
- Add/remove quantities in cart
- Select pickup slot and place demo orders
- Order tracking page with demo status progression
- Staff dashboard to update order statuses and menu availability
- Responsive landing page and menu UI

## Run locally
1. Install Node.js (LTS).
2. Extract this project folder.
3. Open a terminal in the folder and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open http://localhost:3000

## Important MVP limitations
- No backend/database: state is held in React Context and resets on refresh.
- No real payment, authentication, notifications, or live queue sensors.
- Crowd meter is described in the concept but intentionally not represented as real live data in this starter MVP.
- Staff controls are demo controls, not protected admin functionality.

## Suggested GitHub issues
1. Create responsive landing page and navigation
2. Build menu cards, search, and category filters
3. Implement cart state with React Context
4. Add pickup slot selection and demo checkout
5. Build order tracking page
6. Build staff dashboard for status and availability
7. Test mobile layout and main user flows

## Suggested repository description
QueueLess is a smart campus canteen pre-ordering MVP that lets students browse a sample menu, place demo orders, choose pickup slots, and track order status.
