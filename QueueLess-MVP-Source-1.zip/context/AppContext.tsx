 "use client";
import { createContext, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { initialMenu } from "@/data/menu";
import type { CartItem, FoodItem, Order } from "@/types";
type AppContextType = { menu: FoodItem[]; cart: CartItem[]; orders: Order[]; addToCart:(item:FoodItem)=>void; changeQuantity:(id:number,delta:number)=>void; clearCart:()=>void; placeOrder:(slot:string)=>boolean; toggleAvailability:(id:number)=>void; updateOrderStatus:(id:string)=>void; cartCount:number; cartTotal:number };
const AppContext = createContext<AppContextType | null>(null);
export function AppProvider({children}:{children:ReactNode}) {
 const [menu,setMenu]=useState<FoodItem[]>(initialMenu); const [cart,setCart]=useState<CartItem[]>([]); const [orders,setOrders]=useState<Order[]>([]);
 const addToCart=(item:FoodItem)=>setCart(old=>{const found=old.find(x=>x.id===item.id);return found?old.map(x=>x.id===item.id?{...x,quantity:x.quantity+1}:x):[...old,{...item,quantity:1}]});
 const changeQuantity=(id:number,delta:number)=>setCart(old=>old.map(x=>x.id===id?{...x,quantity:x.quantity+delta}:x).filter(x=>x.quantity>0));
 const clearCart=()=>setCart([]);
 const placeOrder=(slot:string)=>{if(!cart.length)return false;const newOrder:Order={id:`QL${Date.now().toString().slice(-6)}`,items:cart.map(x=>({...x})),total:cart.reduce((s,x)=>s+x.price*x.quantity,0),slot,status:"Placed",createdAt:new Date().toLocaleString()};setOrders(old=>[newOrder,...old]);setCart([]);return true;};
 const toggleAvailability=(id:number)=>setMenu(old=>old.map(x=>x.id===id?{...x,available:!x.available}:x));
 const updateOrderStatus=(id:string)=>setOrders(old=>old.map(o=>{if(o.id!==id)return o;const status=o.status==="Placed"?"Preparing":o.status==="Preparing"?"Ready for pickup":"Ready for pickup";return {...o,status};}));
 const value=useMemo(()=>({menu,cart,orders,addToCart,changeQuantity,clearCart,placeOrder,toggleAvailability,updateOrderStatus,cartCount:cart.reduce((s,x)=>s+x.quantity,0),cartTotal:cart.reduce((s,x)=>s+x.price*x.quantity,0)}),[menu,cart,orders]);
 return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export function useApp(){const value=useContext(AppContext);if(!value)throw new Error("useApp must be used inside AppProvider");return value;}
