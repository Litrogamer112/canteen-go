import type { FoodItem } from "@/types";
export const initialMenu: FoodItem[] = [
 {id:1,name:"Masala Dosa",description:"Crispy dosa with potato masala and chutney.",category:"Breakfast",price:45,emoji:"🥞",available:true,popular:true},
 {id:2,name:"Veg Sandwich",description:"Toasted sandwich with fresh vegetables.",category:"Snacks",price:40,emoji:"🥪",available:true,popular:true},
 {id:3,name:"Idli Sambar",description:"Soft idlis served with sambar and chutney.",category:"Breakfast",price:35,emoji:"🥣",available:true},
 {id:4,name:"Lemon Rice",description:"South Indian lemon rice with crunchy peanuts.",category:"Meals",price:50,emoji:"🍚",available:true},
 {id:5,name:"Veg Puffs",description:"Flaky pastry filled with spiced vegetables.",category:"Snacks",price:20,emoji:"🥐",available:true},
 {id:6,name:"Fresh Lime",description:"Refreshing lime drink, sweet or salted.",category:"Drinks",price:25,emoji:"🍋",available:true},
 {id:7,name:"Paneer Roll",description:"Soft wrap with paneer and mint sauce.",category:"Meals",price:65,emoji:"🌯",available:true},
 {id:8,name:"Filter Coffee",description:"Classic South Indian filter coffee.",category:"Drinks",price:20,emoji:"☕",available:true}
];
