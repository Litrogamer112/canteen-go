 "use client";
import Link from "next/link";
import { useApp } from "@/context/AppContext";
export default function Header(){const {cartCount}=useApp();return <header className="header"><div className="nav container"><Link href="/" className="brand"><span className="brand-mark">Q</span>QueueLess<span className="brand-dot">.</span></Link><nav><Link href="/">Menu</Link><Link href="/orders">My orders</Link><Link href="/admin">Staff</Link></nav><Link className="cart-link" href="/#menu">Cart <b>{cartCount}</b></Link></div></header>}
